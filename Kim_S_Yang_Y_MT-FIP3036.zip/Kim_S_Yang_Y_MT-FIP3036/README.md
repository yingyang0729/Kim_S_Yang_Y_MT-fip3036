# Kim_Sian_Yang_Ying_Midterm3036

Dear Professor Dayna:
All the files in the mian branch and the folder name Kim_S_Yang_Y_MT-fip.
Sian Kim and Ying Yang finish the Midterm-FIP in 3036. Sian Kim designs 3 pages mobile and 3 pages desktop APP. Ying Yang makes the prototype links for all APPs, gives all feedback, writes all documents and records the video. 
Ying Yang might record a little long video, so you can drag and skip.
Thanks for you help.
Ying Yang
